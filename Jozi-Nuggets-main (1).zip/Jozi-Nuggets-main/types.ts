export enum View {
  HOME = 'HOME',
  ABOUT = 'ABOUT',
  COMMUNITY = 'COMMUNITY',
  GALLERY = 'GALLERY',
  FEES = 'FEES',
  FAN_ART = 'FAN_ART',
  COACH_CORNER = 'COACH_CORNER',
  REGISTRATION = 'REGISTRATION',
  CONTACT = 'CONTACT',
}

export interface NavItem {
  label: string;
  view: View;
}

export type ImageSize = '1K' | '2K' | '4K';

export interface GeneratedImage {
  url: string;
  prompt: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  isThinking?: boolean;
}