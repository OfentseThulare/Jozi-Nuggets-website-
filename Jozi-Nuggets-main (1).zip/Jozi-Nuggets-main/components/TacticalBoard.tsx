import React, { useState } from 'react';
import { askCoach } from '../services/geminiService';
import { Message } from '../types';
import { Loader2, BrainCircuit, Send } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const TacticalBoard: React.FC = () => {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Welcome to the Locker Room. I'm your AI Tactical Assistant. Ask me about complex game situations, breaking specific defenses, or player development strategies. I'll think deep to give you the winning edge." }
  ]);
  const [isThinking, setIsThinking] = useState(false);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    const userMsg: Message = { role: 'user', text: query };
    setMessages(prev => [...prev, userMsg]);
    setQuery('');
    setIsThinking(true);

    try {
      const responseText = await askCoach(userMsg.text);
      const botMsg: Message = { role: 'model', text: responseText };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, coach. I lost focus. Please try asking again." }]);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 h-[80vh] flex flex-col">
      <div className="bg-nuggets-navy p-6 rounded-t-xl shadow-lg flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-nuggets-gold flex items-center gap-2">
            <BrainCircuit /> Tactical Board
          </h2>
          <p className="text-gray-300 text-sm">Powered by Gemini 3.0 Pro Thinking Mode</p>
        </div>
      </div>

      <div className="flex-1 bg-gray-50 border-x border-b border-gray-200 p-6 overflow-y-auto rounded-b-xl shadow-inner space-y-6">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[85%] p-5 rounded-2xl ${
                msg.role === 'user'
                  ? 'bg-nuggets-navy text-white rounded-br-none'
                  : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-sm'
              }`}
            >
              {msg.role === 'model' ? (
                <div className="prose prose-sm max-w-none prose-headings:text-nuggets-navy">
                  <ReactMarkdown>{msg.text}</ReactMarkdown>
                </div>
              ) : (
                <p>{msg.text}</p>
              )}
            </div>
          </div>
        ))}
        {isThinking && (
          <div className="flex justify-start">
            <div className="bg-white border border-gray-200 p-4 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-3">
              <Loader2 className="animate-spin text-nuggets-gold" size={24} />
              <span className="text-gray-500 italic">Analyzing game tape... (Thinking Budget: 32k)</span>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleAsk} className="mt-4 flex gap-2">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask a complex tactical question..."
          className="flex-1 p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nuggets-navy shadow-sm"
          disabled={isThinking}
        />
        <button
          type="submit"
          disabled={isThinking || !query}
          className="bg-nuggets-gold text-nuggets-navy px-8 rounded-xl font-bold hover:bg-yellow-400 disabled:opacity-50 transition-colors flex items-center gap-2"
        >
          <Send size={20} />
          Ask
        </button>
      </form>
    </div>
  );
};

export default TacticalBoard;