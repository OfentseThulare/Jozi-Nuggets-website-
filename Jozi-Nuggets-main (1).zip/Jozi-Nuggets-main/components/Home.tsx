
import React from 'react';
import { 
  Trophy, 
  Users, 
  ArrowRight, 
  Award,
  Play,
  CheckCircle2,
  Calendar,
  MapPin
} from 'lucide-react';
import { View } from '../types';

// --- SUB-COMPONENTS ---

const CountdownTimer = () => {
    return (
        <div className="container mx-auto px-6 relative z-20 -mt-16 mb-24">
            <div className="bg-white rounded-none shadow-2xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between border-b-4 border-nuggets-gold bg-hex-pattern">
                <div className="mb-8 md:mb-0 text-center md:text-left">
                    <div className="inline-block border border-dashed border-nuggets-gold text-nuggets-navy px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-3">
                        Next Match
                    </div>
                    <h3 className="text-3xl md:text-4xl font-black text-nuggets-navy leading-none font-display uppercase">
                        The next best event <br/> starts in
                    </h3>
                </div>
                
                <div className="flex gap-8 md:gap-12">
                    {[
                        { val: '02', label: 'Days' },
                        { val: '14', label: 'Hours' },
                        { val: '35', label: 'Mins' },
                        { val: '12', label: 'Secs' }
                    ].map((item, i) => (
                        <div key={i} className="text-center group cursor-default">
                            <div className="text-5xl md:text-7xl font-black text-gray-300 group-hover:text-nuggets-navy transition-colors font-display leading-none">
                                {item.val}
                            </div>
                            <div className="text-xs font-bold text-nuggets-gold uppercase tracking-widest mt-2">
                                {item.label}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="hidden lg:block">
                     <button className="px-8 py-4 border-2 border-nuggets-navy text-nuggets-navy font-bold uppercase tracking-wider hover:bg-nuggets-navy hover:text-white transition-all font-display">
                        Get Ticket
                     </button>
                </div>
            </div>
        </div>
    )
}

const HeroSection = ({ onNavigate }: { onNavigate: (view: View) => void }) => (
  <section className="relative w-full h-screen flex items-center bg-nuggets-navy overflow-hidden">
    {/* Background Image with Overlay */}
    <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=2090&auto=format&fit=crop" 
          alt="Basketball Court" 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-nuggets-navy via-nuggets-navy/60 to-transparent"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
    </div>

    <div className="container mx-auto px-6 relative z-10 pt-20 text-center">
        <div className="inline-block px-6 py-2 border border-white/30 rounded-full backdrop-blur-sm mb-6 animate-fade-in">
            <span className="text-nuggets-gold font-bold uppercase tracking-[0.2em] text-sm">Blue Collar Gold Swagger</span>
        </div>
        <h1 className="text-6xl md:text-9xl font-black text-white leading-[0.85] mb-8 uppercase tracking-tighter font-display drop-shadow-2xl">
          Welcome to <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400">Jozi Nuggets</span>
        </h1>
        <p className="text-xl text-gray-300 leading-relaxed max-w-2xl mx-auto mb-10 font-light">
          We are the premier basketball club in Johannesburg, turning raw talent into disciplined athletes through professional training.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-6">
          <button 
            onClick={() => onNavigate(View.ABOUT)}
            className="px-10 py-4 bg-nuggets-navy border border-nuggets-gold text-white font-black text-lg uppercase tracking-wider hover:bg-nuggets-gold hover:text-nuggets-navy transition-all font-display"
          >
            Learn More
          </button>
        </div>
    </div>
  </section>
);

const AboutIntroSection = ({ onNavigate }: { onNavigate: (view: View) => void }) => (
    <section className="py-24 bg-white bg-hex-pattern relative overflow-hidden">
        {/* Background Hex decoration */}
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gray-50 rounded-full opacity-50 blur-3xl -z-10 translate-x-1/2 -translate-y-1/2"></div>

        <div className="container mx-auto px-6">
            <div className="flex flex-col lg:flex-row items-center gap-16">
                <div className="lg:w-1/2">
                    <div className="inline-block px-4 py-1 border border-nuggets-navy text-nuggets-navy font-bold uppercase tracking-wider text-xs mb-6 rounded-full">
                        Our Club
                    </div>
                    <h2 className="text-5xl md:text-7xl font-black text-nuggets-navy mb-8 leading-[0.9] uppercase font-display">
                        We are the leader <br/> in <span className="text-nuggets-gold">sports education</span>
                    </h2>
                    <p className="text-gray-600 text-lg leading-relaxed mb-6">
                        Jozi Nuggets was established with the vision to integrate sports and education to encourage young sports enthusiasts and support professional athletes.
                    </p>
                    <p className="text-gray-600 text-lg leading-relaxed mb-10 border-l-4 border-nuggets-gold pl-6">
                        The Jozi Nuggets is the only institution in Johannesburg that integrates sports and education to create the perfect training ground for champions of tomorrow.
                    </p>
                    <button 
                        onClick={() => onNavigate(View.ABOUT)}
                        className="bg-nuggets-navy text-white px-10 py-4 font-bold uppercase tracking-wider hover:bg-nuggets-gold hover:text-nuggets-navy transition-colors font-display"
                    >
                        About Our Club
                    </button>
                </div>
                
                <div className="lg:w-1/2 relative">
                    <div className="relative z-10">
                        {/* Main Image with Clipping Mask styling */}
                        <div className="relative">
                            <div className="absolute inset-0 bg-nuggets-gold transform translate-x-4 translate-y-4 -z-10"></div>
                            <img 
                                src="https://images.unsplash.com/photo-1519861531473-920026393112?q=80&w=1974&auto=format&fit=crop" 
                                alt="Basketball training" 
                                className="w-full shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
                            />
                        </div>
                    </div>
                    
                    {/* Floating Stats Card matching reference */}
                    <div className="absolute -bottom-12 -left-12 z-20 bg-nuggets-gold p-10 shadow-[0_20px_50px_rgba(0,0,0,0.3)] max-w-xs animate-fade-in hidden md:block">
                        <div className="text-7xl font-black text-white mb-2 font-display">50+</div>
                        <div className="text-nuggets-navy font-bold uppercase tracking-widest border-t-2 border-nuggets-navy pt-4 text-sm">
                            Championship Awards Won
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
);

const ProgramsSection = ({ onNavigate }: { onNavigate: (view: View) => void }) => {
  const programs = [
    {
      title: "Junior Academy",
      desc: "Fundamentals",
      img: "/jozi_junior.jpg",
      fallback: "https://images.unsplash.com/photo-1526976668912-1a811878dd37?q=80&w=2070&auto=format&fit=crop" // Kids playing
    },
    {
      title: "Youth League",
      desc: "Competitive",
      img: "/jozi_youth.jpg",
      fallback: "https://images.unsplash.com/photo-1518407613690-d9fc990e795f?q=80&w=2070&auto=format&fit=crop" // Youth/High school
    },
    {
      title: "Senior Squads",
      desc: "Pro Level",
      img: "/jozi_senior.jpg",
      fallback: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=2069&auto=format&fit=crop" // Pro game
    },
    {
      title: "Outreach",
      desc: "Community",
      img: "https://images.unsplash.com/photo-1448832984292-14be11385149?q=80&w=2070&auto=format&fit=crop",
      fallback: "https://images.unsplash.com/photo-1448832984292-14be11385149?q=80&w=2070&auto=format&fit=crop"
    }
  ];

  return (
    <section className="w-full bg-[#111111] py-24 relative">
        <div className="absolute left-0 top-0 h-full w-px bg-white/10 ml-10 hidden md:block"></div>
        <div className="absolute left-0 top-0 h-full w-px bg-white/10 ml-20 hidden md:block"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-end mb-20">
            <div className="max-w-2xl">
                <div className="inline-block px-4 py-1 border border-white/20 rounded-full text-white/60 font-bold uppercase tracking-wider text-xs mb-4">
                    Our Programs
                </div>
                <h2 className="text-5xl md:text-6xl font-black text-white uppercase leading-tight font-display">
                    Types of sports <br/> we are <span className="text-nuggets-gold">focused</span>
                </h2>
                <p className="text-gray-400 mt-6 max-w-lg">
                    In order to promote budding talent and provide world class sports training facilities in the country.
                </p>
            </div>
            <button 
                onClick={() => onNavigate(View.FEES)}
                className="hidden md:block px-8 py-4 border border-nuggets-gold text-nuggets-gold font-bold uppercase tracking-wider hover:bg-nuggets-gold hover:text-nuggets-navy transition-all font-display"
            >
                See All Programs
            </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {programs.map((prog, i) => (
            <div key={i} className="group relative h-[500px] overflow-hidden cursor-pointer">
              <img 
                src={prog.img} 
                alt={prog.title} 
                onError={(e) => {
                    e.currentTarget.src = prog.fallback;
                }}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-90 transition-opacity duration-300"></div>
              
              {/* Content */}
              <div className="absolute bottom-0 left-0 p-8 w-full z-10">
                <h3 className="text-3xl font-black text-white uppercase mb-2 font-display">{prog.title}</h3>
                <p className="text-gray-300 text-sm font-medium tracking-wide uppercase mb-6">{prog.desc}</p>
                
                <div className="w-12 h-12 rounded-full border border-white/30 flex items-center justify-center text-white group-hover:bg-nuggets-gold group-hover:border-nuggets-gold group-hover:text-nuggets-navy transition-all duration-300">
                    <ArrowRight size={20} className="transform -rotate-45 group-hover:rotate-0 transition-transform duration-300" />
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 md:hidden text-center">
             <button 
                onClick={() => onNavigate(View.FEES)}
                className="px-8 py-4 border border-nuggets-gold text-nuggets-gold font-bold uppercase tracking-wider hover:bg-nuggets-gold hover:text-nuggets-navy transition-all font-display w-full"
            >
                See All Programs
            </button>
        </div>
      </div>
    </section>
  );
};

const FeaturesSection = () => {
    const features = [
        {
            num: "01",
            title: "Choose your Sports",
            desc: "Dreams needs to be driven by passion to make it come true. Select your preferred division.",
            icon: <Trophy size={28} />
        },
        {
            num: "02",
            title: "Train by Professional",
            desc: "Based on your sports dream the trainer will assigned to you. We have the best in the city.",
            icon: <Users size={28} />
        },
        {
            num: "03",
            title: "Become a Pro",
            desc: "With the prefect training under professional you become PRO. We pave the way.",
            icon: <Award size={28} />
        }
    ];

    return (
        <section className="py-24 bg-white relative overflow-hidden bg-hex-pattern">
             {/* Splash effect background */}
            <div className="absolute top-0 right-0 h-full w-2/3 bg-gray-50 skew-x-12 translate-x-32 -z-10"></div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                    <div>
                         <div className="inline-block px-4 py-1 border border-dashed border-nuggets-navy text-nuggets-navy font-bold uppercase tracking-wider text-xs mb-6 rounded-full">
                            Why We Are
                        </div>
                        <h2 className="text-5xl md:text-7xl font-black text-nuggets-navy mb-8 leading-[0.9] uppercase font-display">
                            The Best Sports <br/> Club with all <br/> inbuilt <span className="text-nuggets-gold">features</span>
                        </h2>
                        <button className="bg-nuggets-navy text-white px-10 py-4 font-bold uppercase tracking-wider hover:bg-nuggets-gold hover:text-nuggets-navy transition-colors font-display shadow-xl">
                            Join Our Club
                        </button>
                        
                        <div className="mt-12 text-gray-600 leading-relaxed text-lg border-l-4 border-gray-200 pl-6">
                            The education facilities provided by Jozi Nuggets are similar to regular schools but with professional sports facilities. We have a team of professional teachers with great teaching experience.
                        </div>
                    </div>

                    <div className="space-y-12">
                        {features.map((feat, i) => (
                            <div key={i} className="flex gap-8 items-start group">
                                <div className="relative shrink-0">
                                    <div className="w-24 h-24 rounded-full border border-dashed border-gray-300 flex items-center justify-center group-hover:border-nuggets-gold transition-colors duration-500">
                                        <div className="w-16 h-16 rounded-full bg-white shadow-lg flex items-center justify-center text-nuggets-navy group-hover:text-nuggets-gold transition-colors">
                                            {feat.icon}
                                        </div>
                                    </div>
                                    <div className="absolute -top-2 -right-2 w-10 h-10 bg-[#ff4d4d] text-white font-black text-sm flex items-center justify-center rounded-full shadow-lg">
                                        {feat.num}
                                    </div>
                                </div>
                                <div>
                                    <h3 className="text-2xl font-bold text-nuggets-navy mb-3 font-display uppercase tracking-wide">{feat.title}</h3>
                                    <p className="text-gray-500 leading-relaxed">{feat.desc}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

const TestimonialsSection = () => (
  <section className="w-full py-24 bg-nuggets-navy relative overflow-hidden">
     {/* Pattern Overlay */}
     <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
     
    <div className="container mx-auto px-6 relative z-10">
      <div className="flex flex-col md:flex-row items-center justify-between mb-16">
          <div>
            <h2 className="text-4xl md:text-6xl font-black text-white uppercase mb-2 font-display">What They Say</h2>
            <div className="h-1 w-20 bg-nuggets-gold"></div>
          </div>
          <div className="mt-6 md:mt-0 flex gap-4">
              <button className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-nuggets-gold hover:text-nuggets-navy hover:border-nuggets-gold transition-all">
                  <ArrowRight className="transform rotate-180" />
              </button>
              <button className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-nuggets-gold hover:text-nuggets-navy hover:border-nuggets-gold transition-all">
                  <ArrowRight />
              </button>
          </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          {
            name: "Thabo Molefe",
            role: "Youth Player",
            img: "https://randomuser.me/api/portraits/men/32.jpg",
            quote: "The coaches push us to work hard but they also support us. I can see my skills and understanding of the game growing every month."
          },
          {
            name: "Sarah Langa",
            role: "Parent",
            img: "https://randomuser.me/api/portraits/women/44.jpg",
            quote: "My child arrived shy and unsure. After a few months at Jozi Nuggets their confidence and discipline improved both on the court and at school."
          },
          {
            name: "David K.",
            role: "Senior Player",
            img: "https://randomuser.me/api/portraits/men/86.jpg",
            quote: "Jozi Nuggets feels like family. We compete to win but we also look after each other and the young players coming behind us."
          }
        ].map((t, i) => (
          <div key={i} className="bg-[#0b101b] border border-white/5 p-10 relative group hover:border-nuggets-gold transition-all duration-300">
             <div className="flex items-center gap-4 mb-8">
                 <img src={t.img} alt={t.name} className="w-14 h-14 rounded-full border-2 border-nuggets-gold object-cover" />
                 <div>
                     <h4 className="text-white font-bold text-lg font-display tracking-wide group-hover:text-nuggets-gold">{t.name}</h4>
                     <p className="text-gray-500 text-xs uppercase tracking-widest font-bold">{t.role}</p>
                 </div>
             </div>
             <p className="text-gray-400 italic group-hover:text-gray-300 transition-colors leading-relaxed">"{t.quote}"</p>
             
             {/* Rating Stars */}
             <div className="flex gap-1 mt-6 text-nuggets-gold text-xs">
                 {[1,2,3,4,5].map(s => <span key={s}>★</span>)}
             </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const GalleryStrip = ({ onNavigate }: { onNavigate: (view: View) => void }) => (
    <section className="py-24 bg-white relative overflow-hidden">
         <div className="absolute top-0 left-0 w-full h-full bg-hex-pattern opacity-30 pointer-events-none"></div>

        <div className="container mx-auto px-6 relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-end mb-16">
                <div>
                     <div className="inline-block px-4 py-1 border border-nuggets-navy text-nuggets-navy font-bold uppercase tracking-wider text-xs mb-6 rounded-full">
                        Our Showcase
                    </div>
                    <h2 className="text-5xl md:text-6xl font-black text-nuggets-navy uppercase font-display leading-none">
                        Our Club <span className="text-nuggets-gold">Gallery</span>
                    </h2>
                </div>
                
                {/* Filter Tabs (Visual Only) */}
                <div className="hidden md:flex gap-4 mt-6 md:mt-0">
                    {['All', 'Training', 'Games', 'Events'].map((tab, i) => (
                        <button key={i} className={`px-6 py-2 text-sm font-bold uppercase tracking-wider ${i === 0 ? 'bg-nuggets-navy text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
                            {tab}
                        </button>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
                 {[101, 102, 103, 104].map((id, i) => (
                     <div key={i} className={`relative group overflow-hidden cursor-pointer ${i % 2 === 0 ? 'mt-0' : 'md:mt-12'}`} onClick={() => onNavigate(View.GALLERY)}>
                         <img 
                            src={`https://picsum.photos/600/800?random=${id}`} 
                            alt="Gallery" 
                            className="w-full h-80 object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                         />
                         <div className="absolute inset-0 bg-nuggets-navy/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                             <div className="w-16 h-16 rounded-full bg-nuggets-gold flex items-center justify-center text-nuggets-navy transform scale-0 group-hover:scale-100 transition-transform duration-300 delay-100 shadow-xl">
                                 <Play fill="currentColor" size={24}/>
                             </div>
                         </div>
                     </div>
                 ))}
            </div>
            
             <button 
                  onClick={() => onNavigate(View.GALLERY)}
                  className="w-full md:w-auto mx-auto block md:hidden mt-12 py-4 bg-nuggets-navy text-white font-bold uppercase tracking-wider font-display"
                >
                    View All Photos
            </button>
        </div>
    </section>
)

interface HomeProps {
    onNavigate: (view: View) => void;
}

export const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  return (
    <div className="w-full animate-fade-in">
      <HeroSection onNavigate={onNavigate} />
      <CountdownTimer />
      <AboutIntroSection onNavigate={onNavigate} />
      <ProgramsSection onNavigate={onNavigate} />
      <FeaturesSection />
      <TestimonialsSection />
      <GalleryStrip onNavigate={onNavigate} />
    </div>
  );
};
