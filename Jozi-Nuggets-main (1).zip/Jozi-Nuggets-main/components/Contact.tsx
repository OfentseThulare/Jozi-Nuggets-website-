import React, { useState } from 'react';
import { Mail, Phone, MapPin, MessageSquare, Send } from 'lucide-react';

const ContactIntroSection = () => (
  <section className="bg-nuggets-navy text-white py-24 text-center">
    <div className="container mx-auto px-6 max-w-3xl">
      <div className="inline-flex items-center justify-center p-3 bg-white/10 rounded-full mb-6">
        <MessageSquare className="text-nuggets-gold mr-2" size={24} />
        <span className="font-bold text-nuggets-gold tracking-wider uppercase text-sm">Get in Touch</span>
      </div>
      <h1 className="text-4xl md:text-5xl font-extrabold mb-6">Talk to Jozi Nuggets</h1>
      <p className="text-xl text-gray-200 leading-relaxed">
        Have questions about training age groups fees or sponsorship. Use the details below or send us a message and we will respond as soon as we can.
      </p>
    </div>
  </section>
);

const ContactDetailsSection = () => (
  <section className="bg-white py-12 border-b border-gray-100">
    <div className="container mx-auto px-6 max-w-5xl">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-nuggets-navy border-b-4 border-nuggets-gold inline-block pb-2">Contact Info</h3>
          <div className="flex items-start gap-4 p-4 rounded-lg bg-gray-50">
            <Mail className="text-nuggets-navy mt-1" />
            <div>
              <p className="font-bold text-gray-900">General Email</p>
              <p className="text-gray-600">info@jozinuggets.co.za</p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-lg bg-gray-50">
            <Phone className="text-nuggets-navy mt-1" />
            <div>
              <p className="font-bold text-gray-900">Phone or WhatsApp</p>
              <p className="text-gray-600">+27 11 123 4567</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-nuggets-navy border-b-4 border-nuggets-gold inline-block pb-2">Locations</h3>
           <div className="flex items-start gap-4 p-4 rounded-lg bg-gray-50">
            <MapPin className="text-nuggets-navy mt-1" />
            <div>
              <p className="font-bold text-gray-900">Training Venues</p>
              <p className="text-gray-600">Inner city Johannesburg and partner schools. Exact addresses will be updated once confirmed.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const MapSection = () => (
  <section className="w-full h-96 bg-gray-200 relative">
    {/* Map Placeholder / Iframe */}
    <iframe 
      width="100%" 
      height="100%" 
      frameBorder="0" 
      scrolling="no" 
      marginHeight={0} 
      marginWidth={0} 
      src="https://maps.google.com/maps?q=Johannesburg%20CBD&t=&z=13&ie=UTF8&iwloc=&output=embed"
      title="Johannesburg CBD Map"
      className="filter grayscale opacity-80 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
    ></iframe>
    <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-sm p-4 rounded-lg shadow-lg max-w-md border-l-4 border-nuggets-navy">
      <p className="text-nuggets-navy font-medium text-sm">
        Training and games take place at venues around Johannesburg. Exact details will be shared once you are registered.
      </p>
    </div>
  </section>
);

const ContactFormSection = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    mobile: '',
    reason: 'Player registration',
    message: ''
  });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    // Reset after delay
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <section className="bg-gray-50 py-24">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="bg-white rounded-xl shadow-xl overflow-hidden">
          <div className="bg-nuggets-navy p-6 text-white text-center">
            <h2 className="text-2xl font-bold">Send us a message</h2>
          </div>
          <div className="p-8 md:p-12">
            {sent ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
                  <Send size={40} />
                </div>
                <h3 className="text-2xl font-bold text-nuggets-navy mb-2">Message Sent!</h3>
                <p className="text-gray-600">We'll get back to you shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full p-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                      value={formState.name}
                      onChange={e => setFormState({...formState, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Email</label>
                    <input 
                      required
                      type="email" 
                      className="w-full p-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                      value={formState.email}
                      onChange={e => setFormState({...formState, email: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Mobile</label>
                    <input 
                      type="tel" 
                      className="w-full p-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                      value={formState.mobile}
                      onChange={e => setFormState({...formState, mobile: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Reason for enquiry</label>
                    <select 
                      className="w-full p-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                      value={formState.reason}
                      onChange={e => setFormState({...formState, reason: e.target.value})}
                    >
                      <option>Player registration</option>
                      <option>Sponsorship</option>
                      <option>Community programmes</option>
                      <option>Other</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Message</label>
                  <textarea 
                    required
                    rows={4}
                    className="w-full p-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                    value={formState.message}
                    onChange={e => setFormState({...formState, message: e.target.value})}
                  ></textarea>
                </div>

                <button type="submit" className="w-full py-3 bg-nuggets-navy text-white font-bold rounded-lg hover:bg-nuggets-gold hover:text-nuggets-navy transition-all duration-300 shadow-md">
                  Send Message
                </button>
                
                <p className="text-center text-xs text-gray-500 mt-4">
                  We usually reply within a few working days. For urgent matters please use the phone or WhatsApp contact.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export const Contact: React.FC = () => {
  return (
    <div className="w-full animate-fade-in">
      <ContactIntroSection />
      <ContactDetailsSection />
      <MapSection />
      <ContactFormSection />
    </div>
  );
};