import React from 'react';
import { Heart, School, Users, Hammer, Handshake, Gift, Mail, ArrowRight } from 'lucide-react';

// --- SECTIONS ---

const IntroCommunitySection = () => (
  <section className="w-full bg-nuggets-navy nuggets-gradient text-white py-24 relative overflow-hidden">
    {/* Decorative background element */}
    <div className="absolute top-0 right-0 w-64 h-64 bg-nuggets-gold rounded-full blur-[100px] opacity-20 transform translate-x-1/2 -translate-y-1/2"></div>
    
    <div className="container mx-auto px-6 relative z-10 text-center max-w-4xl">
      <div className="inline-flex items-center justify-center p-3 bg-white/10 rounded-full mb-6 animate-fade-in">
        <Heart className="text-nuggets-gold mr-2" size={24} />
        <span className="font-bold text-nuggets-gold tracking-wider uppercase text-sm">Social Responsibility</span>
      </div>
      <h1 className="text-5xl md:text-6xl font-extrabold mb-8 leading-tight">
        Basketball <span className="text-nuggets-gold">saving lives</span>
      </h1>
      <p className="text-xl md:text-2xl text-gray-200 leading-relaxed mb-8">
        For Jozi Nuggets basketball is not just a sport. It is a tool to keep young people engaged supported and hopeful. Our community work focuses on giving inner city youth safe courts positive role models and a sense of belonging.
      </p>
      <div className="w-24 h-1 bg-nuggets-gold mx-auto mb-8 rounded-full"></div>
      <p className="text-lg text-gray-300 font-medium italic">
        "Every clinic every talk and every game is a chance to keep a young person close to the court and far from negative influences."
      </p>
    </div>
  </section>
);

const ProgramGridSection = () => {
  const programs = [
    {
      title: "School outreach clinics",
      desc: "We visit schools and community courts to run free or low cost basketball sessions. These clinics introduce young players to basic skills and give them a positive experience of structured sport.",
      icon: <School className="w-8 h-8" />
    },
    {
      title: "Basketball saving lives camps",
      desc: "Holiday and weekend camps that combine basketball drills with life skills sessions on discipline goal setting and teamwork.",
      icon: <Heart className="w-8 h-8" />
    },
    {
      title: "Equipment and court support",
      desc: "Through partners we help schools and communities with hoops balls and kit and support court upgrades where possible so that safe playing spaces remain available.",
      icon: <Hammer className="w-8 h-8" />
    },
    {
      title: "Mentorship and guidance",
      desc: "Older players and coaches give informal mentorship to younger athletes and share guidance about education choices and life paths.",
      icon: <Users className="w-8 h-8" />
    }
  ];

  return (
    <section className="w-full bg-gray-50 py-24">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-nuggets-navy text-center mb-16">Our Initiatives</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {programs.map((prog, i) => (
            <div key={i} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 group">
              <div className="flex items-start gap-6">
                <div className="w-16 h-16 bg-nuggets-navy/5 text-nuggets-navy rounded-xl flex items-center justify-center shrink-0 group-hover:bg-nuggets-gold group-hover:text-nuggets-navy transition-colors duration-300">
                  {prog.icon}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-nuggets-navy mb-3">{prog.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{prog.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const StoryHighlightSection = () => (
  <section className="w-full bg-white py-24">
    <div className="container mx-auto px-6">
      <div className="flex flex-col md:flex-row items-center gap-12 lg:gap-20">
        <div className="w-full md:w-1/2 relative">
          <div className="absolute inset-0 bg-nuggets-gold rounded-2xl transform translate-x-4 translate-y-4"></div>
          <img 
            src="https://picsum.photos/800/600?grayscale&random=20" 
            alt="Community basketball clinic" 
            className="relative z-10 w-full rounded-2xl shadow-xl object-cover aspect-[4/3]"
          />
        </div>
        <div className="w-full md:w-1/2">
          <div className="flex items-center gap-2 mb-4">
             <div className="h-px w-12 bg-nuggets-gold"></div>
             <span className="text-nuggets-gold font-bold uppercase tracking-widest text-sm">Impact Stories</span>
          </div>
          <h2 className="text-4xl font-bold text-nuggets-navy mb-8">A programme in action</h2>
          <p className="text-lg text-gray-600 leading-relaxed mb-6">
            At our inner city junior session you will see seven year olds learning how to dribble and pass while volunteers and senior players support them. 
          </p>
          <p className="text-lg text-gray-600 leading-relaxed">
            Many of these kids live within walking distance of the court. For two hours they are in a safe supervised environment where their effort is celebrated and their potential is visible.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const PartnersSection = () => (
  <section className="w-full bg-gray-50 py-24 border-y border-gray-200">
    <div className="container mx-auto px-6 text-center max-w-4xl">
      <Handshake className="text-nuggets-navy w-12 h-12 mx-auto mb-6 opacity-20" />
      <h2 className="text-3xl font-bold text-nuggets-navy mb-6">Partners who make this possible</h2>
      <p className="text-lg text-gray-600 mb-12">
        Our community work relies on schools venue partners corporate sponsors and individual supporters who share our belief in the power of basketball. We invite new partners to join us in expanding clinics camps and scholarship support.
      </p>
      
      {/* Placeholder for Partner Logos */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-24 bg-white rounded-lg border border-gray-200 flex items-center justify-center font-bold text-gray-400">
            PARTNER LOGO {i}
          </div>
        ))}
      </div>
    </div>
  </section>
);

const SupportCTASection = () => (
  <section className="w-full bg-white py-24">
    <div className="container mx-auto px-6">
      <h2 className="text-3xl font-bold text-nuggets-navy text-center mb-12">Support basketball saving lives</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* Box One */}
        <div className="bg-nuggets-navy text-white p-10 rounded-2xl shadow-xl flex flex-col items-start relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
            <Gift size={120} />
          </div>
          <h3 className="text-2xl font-bold text-nuggets-gold mb-4 relative z-10">Sponsor a programme</h3>
          <p className="text-gray-200 mb-8 flex-grow relative z-10">
            Support clinics camps or specific schools and see your brand linked with real impact.
          </p>
          <button className="bg-nuggets-gold text-nuggets-navy px-6 py-3 rounded-lg font-bold hover:bg-white transition-colors flex items-center gap-2 relative z-10">
            Enquire about sponsorship <ArrowRight size={18}/>
          </button>
        </div>

        {/* Box Two */}
        <div className="bg-gray-100 text-nuggets-navy p-10 rounded-2xl border border-gray-200 flex flex-col items-start relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
            <Users size={120} />
          </div>
          <h3 className="text-2xl font-bold mb-4 relative z-10">Help as an individual</h3>
          <p className="text-gray-600 mb-8 flex-grow relative z-10">
            Donate equipment volunteer at events or assist with logistics.
          </p>
          <button className="bg-nuggets-navy text-white px-6 py-3 rounded-lg font-bold hover:bg-nuggets-gold hover:text-nuggets-navy transition-colors flex items-center gap-2 relative z-10">
            Contact the community team <Mail size={18}/>
          </button>
        </div>
      </div>
    </div>
  </section>
);

export const Community: React.FC = () => {
  return (
    <div className="w-full animate-fade-in">
      <IntroCommunitySection />
      <ProgramGridSection />
      <StoryHighlightSection />
      <PartnersSection />
      <SupportCTASection />
    </div>
  );
};
