
import React from 'react';

interface JoziLogoProps {
  className?: string;
  variant?: 'full' | 'icon' | 'mark-only';
}

export const JoziLogo: React.FC<JoziLogoProps> = ({ className = "w-12 h-12", variant = 'icon' }) => {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      {/* The Graphic Icon */}
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        <defs>
          <linearGradient id="goldGradient" x1="0" y1="0" x2="100" y2="100">
            <stop offset="0%" stopColor="#FFD700" />
            <stop offset="100%" stopColor="#E6C200" />
          </linearGradient>
          <filter id="distress" x="0%" y="0%" width="100%" height="100%">
             <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" result="noise" />
             <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.4 0" in="noise" result="coloredNoise" />
             <feComposite operator="in" in="coloredNoise" in2="SourceGraphic" result="composite" />
          </filter>
        </defs>

        {/* Main Basketball Circle */}
        <circle cx="50" cy="50" r="48" fill="url(#goldGradient)" stroke="#001f3f" strokeWidth="2" />

        {/* Basketball Seams (Simplified for clarity behind skyline) */}
        <path d="M50 2 A 48 48 0 0 1 50 98" stroke="#001f3f" strokeWidth="1.5" fill="none" opacity="0.3" />
        <path d="M2 50 A 48 48 0 0 1 98 50" stroke="#001f3f" strokeWidth="1.5" fill="none" opacity="0.3" />
        <path d="M15 15 Q 50 50 85 15" stroke="#001f3f" strokeWidth="1.5" fill="none" opacity="0.3" />
        <path d="M15 85 Q 50 50 85 85" stroke="#001f3f" strokeWidth="1.5" fill="none" opacity="0.3" />

        {/* Skyline Silhouette */}
        {/* Navy Bottom Background */}
        <path d="M10 70 Q 50 70 90 70 L 90 90 Q 50 98 10 90 Z" fill="#4B0082" /> {/* Purple/Navy base */}
        
        {/* Buildings & Hillbrow Tower */}
        <g fill="#001f3f">
            {/* Hillbrow Tower (Center) */}
            <rect x="47" y="25" width="6" height="60" />
            <rect x="44" y="20" width="12" height="6" rx="2" /> {/* Top pod */}
            <rect x="49" y="10" width="2" height="10" /> {/* Antenna */}

            {/* Ponte City (Right) */}
            <rect x="65" y="45" width="15" height="40" rx="2" />
            <rect x="65" y="45" width="15" height="2" fill="#FFD700" /> {/* Top rim */}

            {/* Other Buildings Left */}
            <rect x="25" y="50" width="10" height="35" />
            <rect x="35" y="55" width="8" height="30" />
            <rect x="15" y="60" width="10" height="25" />
            
            {/* Other Buildings Right */}
            <rect x="60" y="60" width="5" height="25" />
            <rect x="80" y="55" width="8" height="30" />
        </g>
        
        {/* Horizontal Lines at bottom (Reference style) */}
        <g stroke="#FFD700" strokeWidth="1">
            <line x1="20" y1="78" x2="80" y2="78" />
            <line x1="22" y1="82" x2="78" y2="82" />
            <line x1="25" y1="86" x2="75" y2="86" />
        </g>
        
        {/* Text Inside Logo (If detail allows) */}
        {variant === 'full' && (
             <text x="50" y="94" textAnchor="middle" fill="#FFD700" fontSize="6" fontWeight="bold" fontFamily="sans-serif">JOZI NUGGETS</text>
        )}
      </svg>
      
      {/* External Text for Full Logo Mode */}
      {variant === 'full' && (
          <div className="mt-2 text-center leading-none">
              <div className="font-display font-black text-2xl tracking-tighter text-white drop-shadow-md">
                  JOZI <span className="text-nuggets-gold">NUGGETS</span>
              </div>
          </div>
      )}
    </div>
  );
};
