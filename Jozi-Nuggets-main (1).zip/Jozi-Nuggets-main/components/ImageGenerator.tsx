import React, { useState } from 'react';
import { generateFanArt } from '../services/geminiService';
import { ImageSize } from '../types';
import { Loader2, Image as ImageIcon, Download } from 'lucide-react';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<ImageSize>('1K');
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    setError(null);
    setImageUrl(null);

    try {
      const url = await generateFanArt(
        `Basketball art style, Jozi Nuggets Club colors (Navy Blue and Gold), realistic, action shot: ${prompt}`,
        size
      );
      setImageUrl(url);
    } catch (err) {
      setError("Failed to generate image. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-xl shadow-xl overflow-hidden">
        <div className="bg-nuggets-navy p-6 text-center">
          <h2 className="text-3xl font-bold text-nuggets-gold mb-2 flex items-center justify-center gap-2">
            <ImageIcon /> Jozi Nuggets Fan Art Studio
          </h2>
          <p className="text-gray-300">Create custom wallpapers and posters using our advanced AI.</p>
        </div>

        <div className="p-8">
          <form onSubmit={handleGenerate} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Describe your image</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., A player dunking in downtown Johannesburg with the skyline in the background..."
                className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nuggets-navy focus:border-nuggets-navy"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Quality</label>
                <select
                  value={size}
                  onChange={(e) => setSize(e.target.value as ImageSize)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nuggets-navy"
                >
                  <option value="1K">Standard (1K)</option>
                  <option value="2K">High Definition (2K)</option>
                  <option value="4K">Ultra HD (4K)</option>
                </select>
                <p className="text-xs text-gray-500 mt-1">Higher quality takes longer to generate.</p>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || !prompt}
              className={`w-full py-4 rounded-lg font-bold text-lg transition-all ${
                loading || !prompt
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-nuggets-gold text-nuggets-navy hover:bg-nuggets-navy hover:text-nuggets-gold border-2 border-nuggets-gold'
              }`}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 className="animate-spin" /> Creating Art...
                </span>
              ) : (
                'Generate Artwork'
              )}
            </button>
          </form>

          {error && (
            <div className="mt-6 p-4 bg-red-50 text-red-700 rounded-lg border border-red-200">
              {error}
            </div>
          )}

          {imageUrl && (
            <div className="mt-8 animate-fade-in">
              <h3 className="text-xl font-bold text-nuggets-navy mb-4">Your Masterpiece</h3>
              <div className="relative group rounded-lg overflow-hidden shadow-2xl border-4 border-nuggets-navy">
                <img src={imageUrl} alt="Generated Fan Art" className="w-full h-auto object-cover" />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <a
                    href={imageUrl}
                    download={`nuggets-fanart-${Date.now()}.png`}
                    className="bg-nuggets-gold text-nuggets-navy px-6 py-3 rounded-full font-bold flex items-center gap-2 hover:scale-105 transition-transform"
                  >
                    <Download size={20} /> Download
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageGenerator;