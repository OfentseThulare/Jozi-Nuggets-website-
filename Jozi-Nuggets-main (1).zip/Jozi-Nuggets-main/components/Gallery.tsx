import React, { useState } from 'react';
import { Camera, X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';

type Category = 'All' | 'Games' | 'Training' | 'Community' | 'Tournaments';

interface GalleryItem {
  id: number;
  src: string;
  category: Exclude<Category, 'All'>;
  caption: string;
}

const galleryData: GalleryItem[] = [
  { id: 1, src: "https://picsum.photos/800/600?random=101", category: 'Games', caption: "Youth team huddle before a Johannesburg league game" },
  { id: 2, src: "https://picsum.photos/800/800?random=102", category: 'Training', caption: "Junior players learning footwork" },
  { id: 3, src: "https://picsum.photos/800/600?random=103", category: 'Community', caption: "Community clinic session in inner city Johannesburg" },
  { id: 4, src: "https://picsum.photos/600/800?random=104", category: 'Games', caption: "Senior team celebrating after a tight win" },
  { id: 5, src: "https://picsum.photos/800/600?random=105", category: 'Tournaments', caption: "U18 squad at National Championships" },
  { id: 6, src: "https://picsum.photos/800/800?random=106", category: 'Training', caption: "Strength and conditioning session" },
  { id: 7, src: "https://picsum.photos/600/800?random=107", category: 'Community', caption: "School outreach program" },
  { id: 8, src: "https://picsum.photos/800/600?random=108", category: 'Games', caption: "Fast break action shot" },
  { id: 9, src: "https://picsum.photos/800/600?random=109", category: 'Training', caption: "Coach explaining defensive rotations" },
];

const GalleryIntroSection = () => (
  <section className="bg-nuggets-navy text-white py-24 text-center">
    <div className="container mx-auto px-6 max-w-3xl">
      <div className="inline-flex items-center justify-center p-3 bg-white/10 rounded-full mb-6">
        <Camera className="text-nuggets-gold mr-2" size={24} />
        <span className="font-bold text-nuggets-gold tracking-wider uppercase text-sm">Media Center</span>
      </div>
      <h1 className="text-5xl font-extrabold mb-6">Gallery</h1>
      <p className="text-xl text-gray-200 leading-relaxed">
        Explore training sessions game nights tournaments and community clinics from across the Jozi Nuggets family.
      </p>
    </div>
  </section>
);

export const Gallery: React.FC = () => {
  const [filter, setFilter] = useState<Category>('All');
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  const filteredImages = galleryData.filter(
    (item) => filter === 'All' || item.category === filter
  );

  const filters: Category[] = ['All', 'Games', 'Training', 'Community', 'Tournaments'];

  const openLightbox = (item: GalleryItem) => setSelectedImage(item);
  const closeLightbox = () => setSelectedImage(null);

  return (
    <div className="w-full animate-fade-in bg-gray-50 min-h-screen">
      <GalleryIntroSection />

      {/* Filters */}
      <section className="sticky top-20 z-30 bg-white border-b border-gray-200 shadow-sm py-4">
        <div className="container mx-auto px-6 overflow-x-auto">
          <div className="flex justify-center min-w-max gap-4">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 ${
                  filter === f
                    ? 'bg-nuggets-navy text-nuggets-gold shadow-md transform scale-105'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Grid */}
      <section className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredImages.map((item) => (
            <div
              key={item.id}
              onClick={() => openLightbox(item)}
              className="group relative rounded-xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl transition-all duration-300 bg-black aspect-[4/3] md:aspect-auto md:h-80"
            >
              <img
                src={item.src}
                alt={item.caption}
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 opacity-90 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-nuggets-navy/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <span className="text-nuggets-gold text-xs font-bold uppercase tracking-widest mb-2">{item.category}</span>
                <p className="text-white font-medium text-sm leading-snug">{item.caption}</p>
                <div className="absolute top-4 right-4 bg-white/20 p-2 rounded-full backdrop-blur-sm">
                    <ZoomIn className="text-white w-5 h-5" />
                </div>
              </div>
            </div>
          ))}
        </div>
        {filteredImages.length === 0 && (
          <div className="text-center py-20 text-gray-500">
            No images found in this category.
          </div>
        )}
      </section>

      {/* Lightbox */}
      {selectedImage && (
        <div className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center p-4 animate-fade-in backdrop-blur-sm">
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 text-white/70 hover:text-white transition-colors"
          >
            <X size={40} />
          </button>
          
          <div className="max-w-5xl w-full max-h-[90vh] flex flex-col items-center">
            <img
              src={selectedImage.src}
              alt={selectedImage.caption}
              className="max-h-[80vh] w-auto object-contain rounded-lg shadow-2xl border border-white/10"
            />
            <div className="mt-6 text-center">
                <span className="inline-block px-3 py-1 bg-nuggets-gold text-nuggets-navy text-xs font-bold rounded-full mb-3 uppercase tracking-wider">
                    {selectedImage.category}
                </span>
                <p className="text-white text-lg md:text-xl font-medium">{selectedImage.caption}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};