import React from 'react';
import { CheckCircle2, CreditCard, Calendar, Star, ArrowRight } from 'lucide-react';
import { View } from '../types';

const FeesIntroSection = () => (
  <section className="bg-nuggets-navy text-white py-24 text-center relative overflow-hidden">
     <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/basketball.png')] opacity-5"></div>
    <div className="container mx-auto px-6 max-w-3xl relative z-10">
      <h1 className="text-4xl md:text-5xl font-extrabold mb-6">Membership and training fees</h1>
      <p className="text-xl text-gray-200 leading-relaxed">
        Jozi Nuggets keeps its structure simple. We want families to understand exactly what they are paying for and what their players receive in return.
      </p>
    </div>
  </section>
);

const MembershipCardsSection = () => {
  const plans = [
    {
      title: "Junior Academy",
      subtitle: "Ages six to twelve",
      price: "R650",
      period: "/ month",
      desc: "Weekly group practices that focus on fundamentals and fun.",
      features: [
        "Regular training sessions",
        "Friendly games when available",
        "Access to club events",
        "Club t-shirt upon registration"
      ],
      highlight: false
    },
    {
      title: "Youth & High School",
      subtitle: "Ages thirteen to eighteen",
      price: "R850",
      period: "/ month",
      desc: "Structured practices and league games for committed young players.",
      features: [
        "Two or more practices per week",
        "League registration included",
        "Game and training feedback",
        "Performance tracking"
      ],
      highlight: true
    },
    {
      title: "Senior Squads",
      subtitle: "Competitive Men & Women",
      price: "TBD",
      period: "with coach",
      desc: "Team training and competition for serious athletes.",
      features: [
        "Team practices",
        "League and tournament participation",
        "Access to club support network",
        "Scouting opportunities"
      ],
      highlight: false
    }
  ];

  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, i) => (
            <div 
              key={i} 
              className={`relative rounded-2xl p-8 flex flex-col transition-all duration-300 hover:shadow-xl ${
                plan.highlight 
                  ? 'bg-white border-2 border-nuggets-gold shadow-lg transform md:-translate-y-4' 
                  : 'bg-white border border-gray-200 shadow-sm'
              }`}
            >
              {plan.highlight && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-nuggets-gold text-nuggets-navy px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  Most Popular
                </div>
              )}
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-nuggets-navy">{plan.title}</h3>
                <p className="text-nuggets-gold font-bold text-sm uppercase tracking-wide mb-6">{plan.subtitle}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold text-gray-900">{plan.price}</span>
                  <span className="text-gray-500 font-medium">{plan.period}</span>
                </div>
                <p className="text-gray-600 mt-4 leading-relaxed text-sm">{plan.desc}</p>
              </div>
              
              <ul className="space-y-4 mb-8 flex-grow">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-start gap-3 text-sm text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                    {feat}
                  </li>
                ))}
              </ul>

              <button className={`w-full py-3 rounded-lg font-bold transition-colors ${
                plan.highlight
                  ? 'bg-nuggets-navy text-white hover:bg-nuggets-gold hover:text-nuggets-navy'
                  : 'bg-gray-100 text-nuggets-navy hover:bg-gray-200'
              }`}>
                Select Plan
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ExtrasSection = () => (
  <section className="py-24 bg-white border-y border-gray-100">
    <div className="container mx-auto px-6 max-w-4xl">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold text-nuggets-navy mb-4">Extra Options</h2>
        <p className="text-gray-600">Players can also book additional support outside regular team practices where available.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="flex gap-6 p-6 rounded-xl bg-gray-50 border border-gray-100">
          <div className="w-12 h-12 bg-nuggets-navy/10 text-nuggets-navy rounded-full flex items-center justify-center shrink-0">
            <Star size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-nuggets-navy mb-2">Private skill sessions</h3>
            <p className="text-gray-600">One on one or small group sessions with a coach for focused improvement on shooting, ball handling, or defense.</p>
          </div>
        </div>
        
        <div className="flex gap-6 p-6 rounded-xl bg-gray-50 border border-gray-100">
           <div className="w-12 h-12 bg-nuggets-navy/10 text-nuggets-navy rounded-full flex items-center justify-center shrink-0">
            <Calendar size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-nuggets-navy mb-2">Holiday camps</h3>
            <p className="text-gray-600">Intensive holiday programmes with multiple sessions over a short period to keep fit during breaks.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const PaymentInfoSection = () => (
  <section className="py-24 bg-gray-50">
    <div className="container mx-auto px-6 max-w-3xl text-center">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-white rounded-full shadow-sm mb-6 text-nuggets-navy">
        <CreditCard size={32} />
      </div>
      <h2 className="text-3xl font-bold text-nuggets-navy mb-6">How payments work</h2>
      <p className="text-lg text-gray-600 leading-relaxed">
        Fees are usually paid monthly in advance. New players pay a once off registration fee that covers administration and basic club onboarding. Exact amounts and banking details will be confirmed once you complete the registration form.
      </p>
    </div>
  </section>
);

const FeesCTASection = ({ onNavigate }: { onNavigate: (view: View) => void }) => (
  <section className="py-24 bg-nuggets-navy text-white text-center">
    <div className="container mx-auto px-6 max-w-3xl">
      <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to sign up?</h2>
      <p className="text-xl text-gray-200 mb-10">
        If you are happy with the structure the next step is to complete the registration form. Our team will reply with exact fees for your age group and season details.
      </p>
      <button 
        onClick={() => onNavigate(View.REGISTRATION)}
        className="bg-nuggets-gold text-nuggets-navy px-10 py-4 rounded-lg font-bold text-lg hover:bg-white transition-all shadow-lg flex items-center gap-2 mx-auto"
      >
        Go to registration <ArrowRight />
      </button>
    </div>
  </section>
);

interface FeesProps {
  onNavigate: (view: View) => void;
}

export const Fees: React.FC<FeesProps> = ({ onNavigate }) => {
  return (
    <div className="w-full animate-fade-in">
      <FeesIntroSection />
      <MembershipCardsSection />
      <ExtrasSection />
      <PaymentInfoSection />
      <FeesCTASection onNavigate={onNavigate} />
    </div>
  );
};