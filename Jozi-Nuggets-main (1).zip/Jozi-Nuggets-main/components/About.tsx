import React from 'react';
import { Target, Heart, Hammer, Shield, TrendingUp, Users, Award, Play } from 'lucide-react';

const IntroStorySection = () => (
  <section className="w-full bg-white bg-hex-pattern py-24 relative overflow-hidden">
    <div className="container mx-auto px-6 max-w-5xl text-center relative z-10">
      <div className="inline-block px-4 py-1 border border-nuggets-navy text-nuggets-navy font-bold uppercase tracking-wider text-xs mb-8 rounded-full">
         The Beginning
      </div>
      <h1 className="text-6xl md:text-8xl font-black text-nuggets-navy mb-12 uppercase tracking-tighter font-display">
        Our <span className="text-nuggets-gold">Story</span>
      </h1>
      <div className="space-y-8 text-2xl text-gray-700 leading-relaxed font-light">
        <p>
          Jozi Nuggets started as a small group of players who simply wanted a place to hoop in Johannesburg. Over time that group grew into a structured club that now competes in top city and national competitions while still staying close to its inner city roots.
        </p>
        <p className="text-lg text-gray-500">
          The club was built on the idea that talent is everywhere in Johannesburg but opportunity is not. Jozi Nuggets exists to give committed young people a pathway from the streets and school courts of the city into organised training competitive leagues and even national exposure.
        </p>
      </div>
    </div>
  </section>
);

const MissionValuesSection = () => {
  const values = [
    { title: "Discipline", desc: "We arrive prepared we work hard and we respect time and effort.", icon: <Hammer size={24} /> },
    { title: "Family culture", desc: "We support each other and create a safe space for growth.", icon: <Heart size={24} /> },
    { title: "Work ethic", desc: "We embrace blue collar effort every drill every possession.", icon: <TrendingUp size={24} /> },
    { title: "Respect", desc: "We respect team mates opponents officials and the game itself.", icon: <Shield size={24} /> },
    { title: "Opportunity", desc: "We open doors through training exposure and education support where possible.", icon: <Target size={24} /> },
  ];

  return (
    <section className="w-full bg-nuggets-navy py-24 text-white relative overflow-hidden">
       {/* Decorative diagonal split */}
       <div className="absolute top-0 right-0 w-2/3 h-full bg-[#0b101b] skew-x-[-20deg] transform translate-x-1/4"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row gap-20">
          {/* Mission */}
          <div className="lg:w-1/3 pt-10">
            <h2 className="text-5xl font-black text-white mb-8 uppercase tracking-tight flex items-center gap-3 font-display">
               Our Mission
            </h2>
            <p className="text-xl text-gray-300 leading-relaxed border-l-4 border-nuggets-gold pl-6">
              To use basketball as a tool to build disciplined confident and responsible leaders in Johannesburg while competing at the highest level we can on the court.
            </p>
          </div>

          {/* Values */}
          <div className="lg:w-2/3">
            <h2 className="text-5xl font-black text-white mb-10 uppercase tracking-tight font-display text-right">What we stand for</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {values.map((v, i) => (
                <div key={i} className="flex gap-6 items-start bg-white/5 p-8 border border-white/5 hover:border-nuggets-gold transition-colors group">
                  <div className="w-14 h-14 bg-nuggets-gold flex items-center justify-center text-nuggets-navy shrink-0 font-bold text-xl skew-x-[-10deg]">
                    <span className="skew-x-[10deg]">{i+1}</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-xl mb-3 uppercase tracking-wide font-display group-hover:text-nuggets-gold">{v.title}</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">{v.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ClubStructureSection = () => (
  <section className="w-full bg-white py-24 bg-hex-pattern">
    <div className="container mx-auto px-6">
      <div className="max-w-4xl mx-auto text-center mb-20">
        <h2 className="text-5xl md:text-6xl font-black text-nuggets-navy mb-8 uppercase tracking-tight font-display">How the club is structured</h2>
        <p className="text-gray-600 text-xl font-light">
          Jozi Nuggets is a complete pathway system. We have junior groups for new players, youth teams for high school athletes, and senior teams for men and women.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { title: "Junior Academy", desc: "Entry level programme focused on fundamentals fun and confidence.", icon: <Users size={40}/>, img: "https://images.unsplash.com/photo-1544919978-87066a50f96c?q=80&w=2070&auto=format&fit=crop" },
          { title: "Youth Teams", desc: "High school players who practise regularly and compete in city leagues.", icon: <TrendingUp size={40} />, img: "https://images.unsplash.com/photo-1574602305366-eb9a0ddb9edc?q=80&w=2073&auto=format&fit=crop" },
          { title: "Senior Squads", desc: "Men and women who represent the club in national competitions.", icon: <Award size={40} />, img: "https://images.unsplash.com/photo-1505666287802-931dc83948e9?q=80&w=2071&auto=format&fit=crop" },
        ].map((card, i) => (
          <div key={i} className="group relative h-[500px] overflow-hidden border-b-8 border-nuggets-navy hover:border-nuggets-gold transition-colors shadow-2xl">
             <img src={card.img} alt={card.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale group-hover:grayscale-0" />
             <div className="absolute inset-0 bg-nuggets-navy/90 group-hover:bg-nuggets-navy/40 transition-colors flex flex-col items-center justify-center text-center p-8">
                <div className="text-nuggets-gold mb-6 transform -translate-y-4 group-hover:translate-y-0 transition-transform duration-300 bg-white/10 p-4 rounded-full">{card.icon}</div>
                <h3 className="text-4xl font-black text-white uppercase mb-4 font-display tracking-wide">{card.title}</h3>
                <p className="text-gray-100 font-medium opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">{card.desc}</p>
             </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// Data structure for leaders to allow easy expansion
interface Leader {
  role: string;
  name: string;
  bio: string;
  img: string;
}

const LeadershipSection = () => {
  const leaders: Leader[] = [
    {
      role: "Club Founder & Head Coach",
      name: "Andile Hlophe",
      bio: "Our founder has invested more than a decade into building Jozi Nuggets and the wider basketball ecosystem. With experience in coaching court development and youth programmes he brings both technical knowledge and a deep passion for inner city talent.",
      img: "https://picsum.photos/400/500?grayscale&random=10"
    },
    {
      role: "Programme Director",
      name: "Sarah Mokoena",
      bio: "The programme director oversees training plans team structures and communication with parents and players. Their focus is to make sure every player follows a clear development pathway.",
      img: "https://picsum.photos/400/500?grayscale&random=11"
    },
    // New entries added as per request for expanded layout
    {
      role: "Senior Coach",
      name: "Thabo Sethole",
      bio: "Specializing in defensive strategies and conditioning, Thabo ensures our athletes are physically ready for the highest level of competition. He brings 15 years of pro experience.",
      img: "https://picsum.photos/400/500?grayscale&random=12"
    },
    {
      role: "Youth Development",
      name: "Lerato Khumalo",
      bio: "Focused on our grassroots initiatives, Lerato introduces the fundamentals of basketball to our youngest players with patience and enthusiasm. She believes champions are made in the basics.",
      img: "https://picsum.photos/400/500?grayscale&random=13"
    }
  ];

  return (
    <section className="w-full bg-[#111111] py-24 relative">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-[#1a1f2e] skew-x-12 translate-x-20"></div>

      <div className="container mx-auto px-6 max-w-6xl relative z-10">
        <div className="text-center mb-20">
             <div className="inline-block px-4 py-1 border border-nuggets-gold text-nuggets-gold font-bold uppercase tracking-wider text-xs mb-4 rounded-full">
                Management
            </div>
            <h2 className="text-5xl md:text-6xl font-black text-white text-center uppercase font-display">Our Leaders</h2>
        </div>
        
        <div className="space-y-12">
          {leaders.map((leader, index) => (
            <div key={index} className="group bg-white flex flex-col md:flex-row h-auto md:h-80 shadow-2xl overflow-hidden hover:shadow-[0_20px_50px_rgba(255,215,0,0.15)] transition-shadow duration-300">
              {/* Image Column (Left) */}
              <div className="w-full md:w-1/3 relative overflow-hidden">
                 <img 
                    src={leader.img} 
                    alt={leader.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale group-hover:grayscale-0" 
                 />
                 <div className="absolute inset-0 bg-nuggets-navy/20 group-hover:bg-transparent transition-colors"></div>
              </div>
              
              {/* Text Column (Right) */}
              <div className="w-full md:w-2/3 p-8 md:p-12 flex flex-col justify-center relative bg-white">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gray-50 rounded-bl-full -mr-12 -mt-12 z-0"></div>
                
                <div className="relative z-10">
                    <div className="flex items-center gap-3 mb-3">
                        <div className="h-px w-8 bg-nuggets-gold"></div>
                        <h4 className="text-nuggets-gold font-bold uppercase tracking-widest text-xs">{leader.role}</h4>
                    </div>
                    <h3 className="text-3xl font-black text-nuggets-navy mb-6 uppercase font-display">{leader.name}</h3>
                    <p className="text-gray-600 leading-relaxed">
                    {leader.bio}
                    </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export const About: React.FC = () => {
  return (
    <div className="w-full animate-fade-in pt-20">
      <IntroStorySection />
      <MissionValuesSection />
      <ClubStructureSection />
      <LeadershipSection />
    </div>
  );
};