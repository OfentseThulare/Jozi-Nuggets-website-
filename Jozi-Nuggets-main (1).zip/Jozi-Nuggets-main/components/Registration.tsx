import React, { useState } from 'react';
import { ClipboardList, CheckCircle2, User, Phone, Mail, Calendar, GraduationCap, Activity, AlertCircle } from 'lucide-react';

const RegistrationIntroSection = () => (
  <section className="bg-nuggets-navy text-white py-24 text-center">
    <div className="container mx-auto px-6 max-w-3xl">
      <div className="inline-flex items-center justify-center p-3 bg-white/10 rounded-full mb-6">
        <ClipboardList className="text-nuggets-gold mr-2" size={24} />
        <span className="font-bold text-nuggets-gold tracking-wider uppercase text-sm">Join the Family</span>
      </div>
      <h1 className="text-4xl md:text-5xl font-extrabold mb-6">Register a player</h1>
      <p className="text-xl text-gray-200 leading-relaxed">
        Complete this form if you or your child would like to join Jozi Nuggets. The more detail you give us the better we can place you in the right programme.
      </p>
    </div>
  </section>
);

const AfterSubmitInfoSection = () => (
  <section className="bg-green-50 border border-green-200 rounded-xl p-8 text-center mt-8 animate-fade-in">
    <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
      <CheckCircle2 size={32} />
    </div>
    <h2 className="text-2xl font-bold text-nuggets-navy mb-4">What happens next</h2>
    <p className="text-gray-700 leading-relaxed max-w-2xl mx-auto mb-6">
      Once you submit the form our staff will review your details and contact you within a few working days. We will confirm your training group fees start date and what to bring to your first session.
    </p>
    <p className="text-sm text-gray-500 font-bold uppercase tracking-wider">Please save our contact details for future reference.</p>
  </section>
);

export const Registration: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    dob: '',
    guardianName: '',
    mobile: '',
    email: '',
    division: 'Junior Academy',
    school: '',
    experience: 'New to the game',
    medical: '',
    consent: false
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, consent: e.target.checked }));
    if (errors.consent) {
        setErrors(prev => ({ ...prev, consent: '' }));
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.fullName.trim()) newErrors.fullName = "Player name is required";
    if (!formData.dob) newErrors.dob = "Date of birth is required";
    if (!formData.mobile.trim()) newErrors.mobile = "Mobile number is required";
    if (!formData.email.trim()) newErrors.email = "Email address is required";
    if (!formData.division) newErrors.division = "Please select a division";
    if (!formData.consent) newErrors.consent = "You must accept the terms";
    
    // Conditional validation: Guardian name required if player is likely a junior (simplified logic for now)
    if (formData.division === 'Junior Academy' && !formData.guardianName.trim()) {
       newErrors.guardianName = "Guardian name is required for juniors";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      // Simulate API call
      setTimeout(() => {
        setIsSubmitted(true);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 500);
    }
  };

  if (isSubmitted) {
    return (
      <div className="w-full min-h-screen bg-gray-50 pb-24">
        <RegistrationIntroSection />
        <div className="container mx-auto px-6 -mt-10 relative z-10">
          <AfterSubmitInfoSection />
        </div>
      </div>
    );
  }

  return (
    <div className="w-full bg-gray-50 pb-24 animate-fade-in">
      <RegistrationIntroSection />

      <section className="container mx-auto px-6 -mt-12 relative z-10">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-xl p-8 md:p-12">
          <form onSubmit={handleSubmit} className="space-y-8">
            
            {/* Personal Details */}
            <div>
              <h3 className="text-xl font-bold text-nuggets-navy mb-6 flex items-center gap-2 border-b pb-2">
                <User className="text-nuggets-gold" /> Player Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Player Full Name *</label>
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    className={`w-full p-4 rounded-lg bg-gray-50 border ${errors.fullName ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all`}
                    placeholder="e.g. Thabo Molefe"
                  />
                  {errors.fullName && <p className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle size={12} className="mr-1"/> {errors.fullName}</p>}
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Date of Birth *</label>
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleChange}
                    className={`w-full p-4 rounded-lg bg-gray-50 border ${errors.dob ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all`}
                  />
                  {errors.dob && <p className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle size={12} className="mr-1"/> {errors.dob}</p>}
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-bold text-gray-700 mb-2">Parent / Guardian Name (For Juniors)</label>
                  <input
                    type="text"
                    name="guardianName"
                    value={formData.guardianName}
                    onChange={handleChange}
                    className={`w-full p-4 rounded-lg bg-gray-50 border ${errors.guardianName ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all`}
                    placeholder="Required for Junior Academy players"
                  />
                  {errors.guardianName && <p className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle size={12} className="mr-1"/> {errors.guardianName}</p>}
                </div>
              </div>
            </div>

            {/* Contact Details */}
            <div>
              <h3 className="text-xl font-bold text-nuggets-navy mb-6 flex items-center gap-2 border-b pb-2">
                <Phone className="text-nuggets-gold" /> Contact Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Mobile Number *</label>
                  <input
                    type="tel"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    className={`w-full p-4 rounded-lg bg-gray-50 border ${errors.mobile ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all`}
                    placeholder="e.g. 082 123 4567"
                  />
                  {errors.mobile && <p className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle size={12} className="mr-1"/> {errors.mobile}</p>}
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Email Address *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full p-4 rounded-lg bg-gray-50 border ${errors.email ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all`}
                    placeholder="e.g. name@example.com"
                  />
                  {errors.email && <p className="text-red-500 text-xs mt-1 flex items-center"><AlertCircle size={12} className="mr-1"/> {errors.email}</p>}
                </div>
              </div>
            </div>

            {/* Basketball Info */}
            <div>
              <h3 className="text-xl font-bold text-nuggets-navy mb-6 flex items-center gap-2 border-b pb-2">
                <Activity className="text-nuggets-gold" /> Basketball Profile
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Preferred Division *</label>
                  <select
                    name="division"
                    value={formData.division}
                    onChange={handleChange}
                    className={`w-full p-4 rounded-lg bg-gray-50 border ${errors.division ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all`}
                  >
                    <option value="Junior Academy">Junior Academy</option>
                    <option value="Youth team">Youth team</option>
                    <option value="Senior women">Senior women</option>
                    <option value="Senior men">Senior men</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Experience Level</label>
                  <select
                    name="experience"
                    value={formData.experience}
                    onChange={handleChange}
                    className="w-full p-4 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                  >
                    <option value="New to the game">New to the game</option>
                    <option value="Some experience">Some experience</option>
                    <option value="Regular player">Regular player</option>
                    <option value="Experienced competitor">Experienced competitor</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                   <label className="block text-sm font-bold text-gray-700 mb-2">Current School or Institution</label>
                   <input
                    type="text"
                    name="school"
                    value={formData.school}
                    onChange={handleChange}
                    className="w-full p-4 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                    placeholder="e.g. Parktown Boys High"
                  />
                </div>
              </div>
            </div>

            {/* Medical Info */}
            <div>
              <h3 className="text-xl font-bold text-nuggets-navy mb-6 flex items-center gap-2 border-b pb-2">
                <Activity className="text-nuggets-gold" /> Medical Information
              </h3>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Medical or physical information we should know about</label>
                <textarea
                  name="medical"
                  value={formData.medical}
                  onChange={handleChange}
                  rows={4}
                  className="w-full p-4 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-nuggets-navy focus:border-transparent transition-all"
                  placeholder="Allergies, previous injuries, or chronic conditions..."
                ></textarea>
              </div>
            </div>

            {/* Consent */}
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
               <label className="flex items-start gap-4 cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="consent" 
                    checked={formData.consent}
                    onChange={handleCheckboxChange}
                    className="mt-1 w-5 h-5 text-nuggets-navy rounded focus:ring-nuggets-navy border-gray-300" 
                  />
                  <span className="text-sm text-gray-700">
                    I confirm that the information given is correct and that I accept that basketball is a physical sport. I understand that by registering, I am agreeing to the club's code of conduct.
                  </span>
               </label>
               {errors.consent && <p className="text-red-500 text-xs mt-2 flex items-center"><AlertCircle size={12} className="mr-1"/> {errors.consent}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-nuggets-gold text-nuggets-navy font-bold text-lg rounded-lg shadow-lg hover:bg-nuggets-navy hover:text-nuggets-gold transition-all duration-300"
            >
              Submit Registration
            </button>

          </form>
        </div>
      </section>
    </div>
  );
};