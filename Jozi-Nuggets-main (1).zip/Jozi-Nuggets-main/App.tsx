
import React, { useState, useEffect } from 'react';
import { Home } from './components/Home';
import { About } from './components/About';
import { Community } from './components/Community';
import { Gallery } from './components/Gallery';
import { Fees } from './components/Fees';
import { Registration } from './components/Registration';
import { Contact } from './components/Contact';
import ImageGenerator from './components/ImageGenerator';
import TacticalBoard from './components/TacticalBoard';
import { JoziLogo } from './components/JoziLogo';
import { View } from './types';
import { Menu, X, Instagram, Facebook, Twitter, Phone, Mail, MapPin } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.HOME);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', view: View.HOME },
    { label: 'About', view: View.ABOUT },
    { label: 'Fees', view: View.FEES },
    { label: 'Gallery', view: View.GALLERY },
    { label: 'Community', view: View.COMMUNITY },
    { label: 'Contact', view: View.CONTACT },
    { label: 'Fan Art AI', view: View.FAN_ART },
    { label: "Coach AI", view: View.COACH_CORNER },
  ];

  const handleNavigate = (view: View) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  const renderView = () => {
    switch (currentView) {
      case View.HOME: return <Home onNavigate={handleNavigate} />;
      case View.ABOUT: return <About />;
      case View.COMMUNITY: return <Community />;
      case View.GALLERY: return <Gallery />;
      case View.FEES: return <Fees onNavigate={handleNavigate} />;
      case View.REGISTRATION: return <Registration />;
      case View.CONTACT: return <Contact />;
      case View.FAN_ART: return <ImageGenerator />;
      case View.COACH_CORNER: return <TacticalBoard />;
      default: return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-900">
      {/* HEADER */}
      <header 
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 border-b border-white/10 ${
          scrolled ? 'bg-nuggets-navy shadow-lg py-2' : 'bg-nuggets-navy py-3'
        }`}
      >
        <div className="container mx-auto px-6 flex items-center justify-between">
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => handleNavigate(View.HOME)}
          >
            {/* LOGO IMPLEMENTATION */}
            <div className="relative group-hover:scale-105 transition-transform duration-300">
                <JoziLogo className="w-14 h-14" variant="icon" />
            </div>
            
            <div className="flex flex-col">
                <span className="text-2xl font-black tracking-tighter text-white leading-none font-display italic">JOZI NUGGETS</span>
                <span className="text-[0.65rem] font-bold text-nuggets-gold tracking-[0.2em] uppercase">Basketball Club</span>
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden xl:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => handleNavigate(item.view)}
                className={`text-sm font-bold uppercase tracking-widest transition-all font-display hover:text-nuggets-gold ${
                  currentView === item.view
                    ? 'text-nuggets-gold'
                    : 'text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button 
              onClick={() => handleNavigate(View.REGISTRATION)}
              className="bg-transparent border-2 border-nuggets-gold text-nuggets-gold px-6 py-2 rounded-none font-black text-sm hover:bg-nuggets-gold hover:text-nuggets-navy transition-all uppercase tracking-wider font-display"
            >
              Join Our Team
            </button>
          </nav>

          {/* Mobile Menu Toggle */}
          <button 
            className="xl:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={32} /> : <Menu size={32} />}
          </button>
        </div>

        {/* Mobile Nav Overlay */}
        {mobileMenuOpen && (
          <div className="xl:hidden bg-nuggets-navy fixed inset-0 z-40 pt-24 px-6 overflow-y-auto">
             <div className="flex flex-col gap-6">
                {navItems.map((item) => (
                  <button
                    key={item.label}
                    onClick={() => handleNavigate(item.view)}
                    className={`text-left text-2xl font-black uppercase tracking-tight py-2 border-b border-white/10 font-display ${
                      currentView === item.view ? 'text-nuggets-gold' : 'text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
                <button 
                  onClick={() => handleNavigate(View.REGISTRATION)}
                  className="bg-nuggets-gold text-nuggets-navy w-full py-4 mt-4 font-black text-lg uppercase tracking-wider font-display"
                >
                  Join Our Team
                </button>
             </div>
          </div>
        )}
      </header>

      {/* MAIN CONTENT */}
      <main className="flex-grow bg-white">
        {renderView()}
      </main>

      {/* FOOTER */}
      <footer className="bg-[#0b0f19] text-white pt-20 pb-10 border-t-2 border-nuggets-gold">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="md:col-span-1">
              <div className="flex items-center gap-3 mb-6">
                <JoziLogo className="w-16 h-16" variant="icon" />
                <div>
                   <h3 className="text-2xl font-black tracking-tighter font-display italic leading-none">JOZI NUGGETS</h3>
                   <p className="text-xs text-nuggets-gold font-bold uppercase tracking-widest">Est. Johannesburg</p>
                </div>
              </div>
              <p className="text-gray-400 mb-6 leading-relaxed text-sm">
                Turning raw talent into disciplined, confident athletes through serious training and real game experience.
              </p>
              <div className="flex gap-4">
                 {[Facebook, Twitter, Instagram].map((Icon, i) => (
                    <div key={i} className="w-10 h-10 border border-white/20 flex items-center justify-center hover:bg-nuggets-gold hover:text-nuggets-navy hover:border-nuggets-gold transition-all cursor-pointer">
                        <Icon size={18} />
                    </div>
                 ))}
              </div>
            </div>
            
            <div>
                <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-6 font-display border-l-4 border-nuggets-gold pl-3">Explore</h4>
                <ul className="space-y-4 text-gray-400 text-sm">
                    <li className="hover:text-white cursor-pointer transition-colors" onClick={() => handleNavigate(View.ABOUT)}>About Us</li>
                    <li className="hover:text-white cursor-pointer transition-colors" onClick={() => handleNavigate(View.HOME)}>Our Programs</li>
                    <li className="hover:text-white cursor-pointer transition-colors" onClick={() => handleNavigate(View.COMMUNITY)}>Latest News</li>
                    <li className="hover:text-white cursor-pointer transition-colors" onClick={() => handleNavigate(View.GALLERY)}>Gallery</li>
                </ul>
            </div>

            <div>
                <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-6 font-display border-l-4 border-nuggets-gold pl-3">Programs</h4>
                <ul className="space-y-4 text-gray-400 text-sm">
                    <li className="hover:text-white cursor-pointer transition-colors">Junior Academy</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Youth League</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Senior Men</li>
                    <li className="hover:text-white cursor-pointer transition-colors">Senior Women</li>
                </ul>
            </div>

            <div>
                <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-6 font-display border-l-4 border-nuggets-gold pl-3">Contact</h4>
                <div className="space-y-4 text-gray-400 text-sm">
                    <div className="flex items-start gap-3">
                        <Phone size={18} className="text-nuggets-gold mt-1"/>
                        <span>+27 11 123 4567</span>
                    </div>
                    <div className="flex items-start gap-3">
                        <Mail size={18} className="text-nuggets-gold mt-1"/>
                        <span>info@jozinuggets.co.za</span>
                    </div>
                    <div className="flex items-start gap-3">
                        <MapPin size={18} className="text-nuggets-gold mt-1"/>
                        <span>Johannesburg CBD,<br/>South Africa</span>
                    </div>
                </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} Jozi Nuggets Basketball Club.</p>
            <p className="mt-2 md:mt-0">Design supported by Atlas Consulting Group.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
