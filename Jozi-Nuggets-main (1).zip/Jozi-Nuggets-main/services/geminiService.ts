import { GoogleGenAI } from "@google/genai";
import { ImageSize } from "../types";

const apiKey = process.env.API_KEY;

// Helper to get client (ensure key exists)
const getClient = () => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please set process.env.API_KEY");
  }
  return new GoogleGenAI({ apiKey });
};

/**
 * Generate High-Quality Images using Nano Banana Pro (gemini-3-pro-image-preview)
 */
export const generateFanArt = async (prompt: string, size: ImageSize): Promise<string> => {
  const ai = getClient();
  
  // Per requirements: gemini-3-pro-image-preview for high quality + size control
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [{ text: prompt }],
    },
    config: {
      imageConfig: {
        imageSize: size, 
        aspectRatio: "16:9", // Good for wallpapers
      },
    },
  });

  // Extract image from response
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }

  throw new Error("No image generated.");
};

/**
 * Tactical Assistant using Thinking Mode (gemini-3-pro-preview)
 */
export const askCoach = async (question: string): Promise<string> => {
  const ai = getClient();

  // Per requirements: gemini-3-pro-preview with thinkingBudget 32768
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: question,
    config: {
      thinkingConfig: {
        thinkingBudget: 32768, // Max budget for deep reasoning
      },
      // Do not set maxOutputTokens as per instructions
    },
  });

  return response.text || "The coach is drawing up a play... (No response text)";
};